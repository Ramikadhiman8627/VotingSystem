<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width,initial-scale=1.0">
        <title> Voting System -Dashboard</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet">
</head>
<style>
    h1
{
  overflow: hidden;
  color:white;
  text-align:center;
  background-color: black;
}
body {
  background-image: url('img.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
}
</style>
<body>
<h1 >Voting System</h1>
    <div>
        <a href="index.php"><button class=" btn btn-dark text-light px-3">Back</button></a>
        <a href="logout.php"><button class=" btn btn-dark text-light px-3">logout</button></a>
    
   <h4 class="text-black ">For More Details CONTACT US</h4>
   <p>email:ramikadhiman22@gmail.com</p>
<p>Phone No. 8627824718</p>
      
</body>
</html>
