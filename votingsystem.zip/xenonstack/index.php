<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width,
        initial-scale=1.0">
        <title> Voting System</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css
" rel="stylesheet">

</head>
<style>
h1
{
  overflow: hidden;
  color:white;
  text-align:center;
  background-color: black;
}

body {
  background-image: url('vote.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
}
footer{
background-color: black;
 font-size: .90em;
 margin-left: 0px;
 padding: 1em;
 font-style: italic;
 text-align: center;
 color: blue;
 margin-top: 120px;
 
}
</style>
<body >
    <h1 >Voting System</h1>
    <div>
        <h2 class="text-center" >Login</h2>
        <div class="container text-center">
            <form action="login.php" method="POST">
                <div class="mb-3">
                    <input type="text" class="form-control w-50 m-auto"
                    name="username" placeholder="Enter your name" required="required">
                </div>
                <div class="mb-3">
                    <input type="text" class="form-control w-50 m-auto"
                    name="mobile" placeholder="Enter your Mobile" required="required" maxlength="10" minlength="10">
                </div>
                <div class="mb-3">
                    <input type="text" class="form-control w-50 m-auto"
                    name="password" placeholder="Enter your password" required="required" >
                </div>
                <div class="mb-3">
                    <select name="std" class="form-select w-50 m-auto">
                        <option value="group">Group</option>
                        <option value="voter">voter</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-dark my-4">Login</button>
                <p>Don't have an account?<a href="registration.php" class="text-blue">Register Here</a></p>
            </form>
        </div>
    </div>
    <footer>
  Copyright © 2022 Online Voting System<br>
    <a href="Ramika@Dhiman.com"> Ramika@Dhiman.com</a>
</footer>
</body>
</html>
