<?php
$con = mysqli_connect("localhost","root","demo123" ,"xenonstack");
if(!$con)
{
die(mysqli_error($con));
}
?>